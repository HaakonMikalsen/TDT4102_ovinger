#pragma once
#include "std_lib_facilities.h"

void writeUserInputToFile(const std::string &filename);
void addLineNumbers(const std::string &filename);