#pragma once

void fillInFibonacciNumbers(int* result, int length);
void printArray(int* array, int length);
void createFibonacci();