#pragma once
#include "std_lib_facilities.h"

// BEGIN: 5a
// Deklarer funksjonen randomWithLimits som tar inn et 
// heltall som nedre grense som første argument og et heltall som øvre grense som andre argument. 
int randomWithLimits(int max, int min);
// END: 5a